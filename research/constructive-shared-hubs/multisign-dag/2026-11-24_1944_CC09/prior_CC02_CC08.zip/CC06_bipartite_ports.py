"""Exact bipartite multipole extension with <=2 non-dominant ports.
Reference enumeration is used only for tests. Requires networkx.
"""
import itertools, random, json
from collections import Counter
import networkx as nx

def solve(G, L, ports, word):
    nL=len(L); nR=len(G)-nL
    if any(sum(c==a and v in L for v,c in zip(ports,word))-sum(c==a and v not in L for v,c in zip(ports,word)) != nL-nR for a in (1,2,3)): return None
    used={v:set() for v in G}
    for v,c in zip(ports,word):
        if c in used[v]: return None
        used[v].add(c)
    a=max((1,2,3),key=word.count)
    if len(word)-word.count(a)>2: raise ValueError('unsupported boundary')
    H=G.subgraph([v for v in G if a not in used[v]])
    matching=nx.algorithms.bipartite.maximum_matching(H,top_nodes=set(H)&L)
    if len(matching)!=len(H): return None
    A={tuple(sorted((v,u))) for v,u in matching.items()}
    color={e:a for e in A}
    # Alternately color all remaining edges including dangling ports, represented by new leaf nodes.
    R=nx.Graph(); R.add_nodes_from(G); R.add_edges_from(e for e in G.edges if tuple(sorted(e)) not in A)
    forced={}
    for i,(v,c) in enumerate(zip(ports,word)):
        if c!=a:
            u=len(G)+i # generator uses contiguous vertices; ensure fresh IDs below
            u=('port',i)
            R.add_edge(v,u);forced[frozenset((v,u))]=c
    b,c=[x for x in (1,2,3) if x!=a]
    for comp in nx.connected_components(R):
        es=list(R.subgraph(comp).edges)
        if not es: continue
        seed=next(((u,v,forced[frozenset((u,v))]) for u,v in es if frozenset((u,v)) in forced),(*es[0],b))
        stack=[seed]; got={}
        while stack:
            u,v,x=stack.pop(); key=frozenset((u,v))
            if key in got:
                if got[key]!=x: return None
                continue
            if key in forced and forced[key]!=x: return None
            got[key]=x
            for t,s in ((u,v),(v,u)):
                stack.extend((t,w,b+c-x) for w in R[t] if w!=s)
        for u,v in es:
            if u in G and v in G: color[tuple(sorted((u,v)))]=got[frozenset((u,v))]
    assert len(color)==len(G.edges)
    for v in G:
        cs=[color[tuple(sorted((v,u)))] for u in G[v]]+[x for p,x in zip(ports,word) if p==v]
        assert sorted(cs)==[1,2,3]
    return color

def brute(G,ports,word):
    used={v:set() for v in G}
    for v,c in zip(ports,word):
        if c in used[v]:return False
        used[v].add(c)
    es=list(G.edges)
    def rec(left):
        if not left:return True
        cand=[(set((1,2,3))-used[u]-used[v],u,v) for u,v in left]
        opts,u,v=min(cand,key=lambda x:len(x[0]))
        for c in opts:
            used[u].add(c);used[v].add(c)
            if rec([e for e in left if e!=(u,v)]):return True
            used[u].remove(c);used[v].remove(c)
        return False
    return rec(es)

def gen(p,rng):
    G=nx.complete_bipartite_graph(3,3) if p==3 else nx.Graph()
    if p!=3:
        G.add_nodes_from(range(2*p)); perms=[list(range(p)),[(i+1)%p for i in range(p)]]
        while True:
            perm=rng.sample(range(p),p)
            if all(perm[i] not in (i,(i+1)%p) for i in range(p)):break
        perms.append(perm)
        for perm in perms:G.add_edges_from((i,p+j) for i,j in enumerate(perm))
    return G,set(range(p))

def main():
    rng=random.Random(606); stats=Counter(); masks=Counter()
    for case in range(100):
        G,L=gen(rng.choice([3,4,5,6]),rng); ports=[]
        mode=case%5
        if mode in (3,4):
            v=rng.choice(list(G));ports.extend(G[v]);G.remove_node(v);L.discard(v)
        for _ in range({0:0,1:1,2:2,3:0,4:1}[mode]):
            u,v=rng.choice(list(G.edges));G.remove_edge(u,v);ports.extend([u,v])
        rng.shuffle(ports)
        assert all(G.degree(v)+ports.count(v)==3 for v in G)
        sat=0
        for w in itertools.product((1,2,3),repeat=len(ports)):
            got=solve(G,L,ports,w) is not None; expected=brute(G,ports,w)
            assert got==expected,(case,ports,w)
            stats['comparisons']+=1;stats['SAT' if got else 'UNSAT']+=1;sat+=got
        masks[(len(ports),sat)]+=1
    out={'seed':606,'graphs':100,'counts':dict(stats),'support_sizes':{str(k):v for k,v in sorted(masks.items())}}
    print(json.dumps(out,indent=2));open('/mnt/data/CC06_bipartite_ports_results.json','w').write(json.dumps(out,indent=2)+'\n')
if __name__=='__main__':main()
