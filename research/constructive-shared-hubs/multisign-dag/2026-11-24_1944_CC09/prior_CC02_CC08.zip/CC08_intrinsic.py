import random,itertools,json

def rank(rows):
    p={}
    for x in rows:
        while x:
            i=x.bit_length()-1
            if i in p:x^=p[i]
            else:p[i]=x;break
    return len(p)

def count(d,eq):
    p={}
    for x,b in eq:
        while x:
            i=x.bit_length()-1
            if i in p:x^=p[i][0];b^=p[i][1]
            else:p[i]=(x,b);break
        if not x and b:return 0
    return 1<<(d-len(p))

def kernel(d,eq):
    # Basis for nullspace, via elimination and free-coordinate substitution.
    p={}
    for x in eq:
        while x:
            i=x.bit_length()-1
            if i in p:x^=p[i]
            else:p[i]=x;break
    out=[]
    for j in range(d):
        if j in p:continue
        v=1<<j
        for i,x in sorted(p.items()):
            if (v&x).bit_count()%2:v|=1<<i
        out.append(v)
    return out

def acquire(d,terms):
    # Frequency-domain affine supports and phases for each nonempty indicator.
    packets=[]
    for c,eq in terms:
        n=count(d,eq)
        if not n:continue
        # Obtain particular solution by self-reduction.
        fixed=[];a=0
        for j in range(d):
            b=int(not count(d,eq+fixed+[(1<<j,0)]));fixed.append((1<<j,b));a|=b<<j
        support=[(v,0) for v in kernel(d,[x for x,b in eq])]
        packets.append((c*n,support,a))
    pairs=[(c*k,s+t,a^b) for c,s,a in packets for k,t,b in packets]
    calls=0
    def energy(q):
        nonlocal calls
        calls+=1; total=0
        for c,s,a in pairs:
            eq=s+q;n=count(d,eq)
            if n:total+=c*(2*count(d,eq+[(a,0)])-n)
        assert total>=0
        return total
    U=[]
    while True:
        h=next((h for h in kernel(d,U) if energy([(h,1)])),None)
        if h is None:return U,calls
        q=[(h,1)];w=0
        for j in range(d):
            b=int(not energy(q+[(1<<j,0)]));q.append((1<<j,b));w|=b<<j
        assert rank(U+[w])==len(U)+1
        U.append(w)

def val(terms,x):return sum(c for c,eq in terms if all((a&x).bit_count()%2==b for a,b in eq))

def run():
    rng=random.Random(82026);checks=0;maxcalls=0
    for d in range(1,9):
        for _ in range(20):
            terms=[(rng.randint(-3,3),[(rng.randrange(1<<d),rng.randrange(2)) for _ in range(rng.randrange(4))]) for _ in range(5)]
            U,calls=acquire(d,terms);f=[val(terms,x) for x in range(1<<d)]
            H=[h for h in range(1<<d) if all(f[x]==f[x^h] for x in range(1<<d))]
            assert len(H)==1<<(d-len(U)) and all(all((h&w).bit_count()%2==0 for w in U) for h in H)
            checks+=1;maxcalls=max(maxcalls,calls)
    scales=[]
    for d in [8,16,32,64,128]:
        # A dense-spectrum point on first 6 coordinates, plus exact cancellation of wide affine terms.
        terms=[(1,[(1<<j,0) for j in range(6)]),(1,[(1<<j,0) for j in range(d)]),(-1,[(1<<j,0) for j in range(d)])]
        U,calls=acquire(d,terms);assert len(U)==6
        scales.append(dict(d=d,rank=len(U),queries=calls))
    out=dict(random_checks=checks,max_random_queries=maxcalls,scaling=scales)
    print(json.dumps(out));open('/mnt/data/CC08_intrinsic_results.json','w').write(json.dumps(out,indent=2))
if __name__=='__main__':run()
