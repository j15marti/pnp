import networkx as nx
from itertools import product
import json

def count(g):
    edges=list(g.edges()); inc={v:set() for v in g}; colors={}
    def rec():
        if len(colors)==len(edges):return 1
        e=min((e for e in edges if e not in colors),key=lambda e:len({1,2,3}-inc[e[0]]-inc[e[1]]))
        u,v=e; total=0
        for c in sorted({1,2,3}-inc[u]-inc[v]):
            colors[e]=c;inc[u].add(c);inc[v].add(c)
            total+=rec();inc[u].remove(c);inc[v].remove(c);del colors[e]
        return total
    return rec()
def expand(g):
    h=nx.Graph(); M=set()
    for v in g:
        ports=[(v,u) for u in g[v]]
        for i in range(3):h.add_edge(ports[i],ports[(i+1)%3])
    for u,v in g.edges():
        a,b=(u,v),(v,u);h.add_edge(a,b);M.add(frozenset((a,b)))
    return h,M
cases=[('K4',nx.complete_graph(4)),('K33',nx.complete_bipartite_graph(3,3)),('cube',nx.cubical_graph()),('Petersen',nx.petersen_graph())]
for n in (6,8,10,12):
    for s in range(5):
        g=nx.random_regular_graph(3,n,seed=100*n+s)
        if nx.is_connected(g):cases.append((f'random-{n}-{s}',g))
rows=[]
for name,g in cases:
    h,M=expand(g); r=h.copy();r.remove_edges_from([tuple(e) for e in M]); parts=list(nx.connected_components(r)); assert len(parts)==len(g) and all(len(p)==3 for p in parts)
    a,b=count(g),count(h);assert a==b
    rows.append(dict(name=name,base_vertices=len(g),expanded_vertices=len(h),base_count=a,expanded_count=b,quotient_rims=len(parts)))
print(json.dumps(rows,indent=2));open('/mnt/data/CC05_triangle_quotient_results.json','w').write(json.dumps(rows,indent=2))
