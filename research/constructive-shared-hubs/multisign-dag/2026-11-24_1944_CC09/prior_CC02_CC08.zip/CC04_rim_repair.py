from itertools import product
from functools import reduce
from operator import xor
import json
from pathlib import Path
import networkx as nx

def phases(h):
    out=[]
    for start in (1,2,3):
        c=start; row=[]
        for v in h:
            c ^= v
            if c==0: break
            row.append(c)
        if len(row)==len(h) and c==start: out.append(tuple(row))
    return out

def reorder(x): return tuple(x[i] for i in (0,4,1,2,3))
def middle(x,y): return tuple(v for pair in zip(reorder(x),y) for v in pair)
S=[x for x in product((1,2,3),repeat=5) if reduce(xor,x)==0]
W={x:sum(c!=3 for c in x) for x in S}
start={x:phases(x) for x in S}; end={x:phases(reorder(x)) for x in S}
trans={x:[(y,len(p),p[0]) for y in S if (p:=phases(middle(x,y)))] for x in S}

def build(k):
    rims=[]; pos=0
    for size in [5]+[10]*(k-1)+[5]:
        rims.append(tuple(range(pos,pos+size)));pos+=size
    G=nx.Graph(); M=set(); bundles=[]
    for r in rims:
        G.add_edges_from(zip(r,r[1:]+r[:1]))
    for i in range(k):
        a=rims[i] if i==0 else rims[i][1::2]
        b=rims[i+1] if i==k-1 else rims[i+1][::2]
        edges=[tuple(sorted((a[j],b[l]))) for l,j in enumerate((0,4,1,2,3))]
        # store in right-port order
        edges=[edges[j] for j in (0,2,3,4,1)]
        bundles.append(edges);M.update(edges);G.add_edges_from(edges)
    assert all(d==3 for _,d in G.degree()) and len(M)==5*k
    return G,M,rims,bundles

def solve(k):
    dp={x:(W[x],len(start[x]),len(start[x])) for x in S if start[x]}; trace=[];checks=0;peak=len(dp)
    for i in range(k-1):
        nd={};tr={}
        for x,(cost,count,optcount) in dp.items():
            for y,multip,_ in trans[x]:
                checks+=1; z=cost+W[y]; old=nd.get(y)
                if old is None: nd[y]=(z,count*multip,optcount*multip);tr[y]=x
                else:
                    oc,ct,ot=old
                    if z<oc: nd[y]=(z,ct+count*multip,optcount*multip);tr[y]=x
                    elif z==oc: nd[y]=(oc,ct+count*multip,ot+optcount*multip)
                    else: nd[y]=(oc,ct+count*multip,ot)
        dp=nd;trace.append(tr);peak=max(peak,len(dp))
    finals=[(c,x,ct*len(end[x]),ot*len(end[x])) for x,(c,ct,ot) in dp.items() if end[x]]
    best,x,_,_=min(finals); count=sum(z[2] for z in finals); opt=sum(z[3] for z in finals if z[0]==best)
    seq=[x]
    for tr in reversed(trace): seq.append(tr[seq[-1]])
    seq.reverse(); G,M,rims,bundles=build(k); col={}
    for b,x in zip(bundles,seq): col.update(zip(b,x))
    hs=[seq[0]]+[middle(x,y) for x,y in zip(seq,seq[1:])]+[reorder(seq[-1])]
    for r,h in zip(rims,hs):
        p=phases(h)[0]
        col.update((tuple(sorted(e)),c) for e,c in zip(zip(r,r[1:]+r[:1]),p))
    assert len(col)==G.number_of_edges()
    assert all({col[tuple(sorted((v,u)))] for u in G[v]}=={1,2,3} for v in G)
    assert best==sum(col[e]!=3 for e in M)==2*k
    return dict(k=k,vertices=len(G),odd_rims=2,minimum_exceptions=best,peak_states=peak,transition_checks=checks,total_colorings=str(count),optimal_colorings=str(opt))

def brute(k):
    G,M,_,_=build(k); es=list(map(lambda e:tuple(sorted(e)),G.edges())); used={v:set() for v in G}; count=0;best=999;opt=0
    def visit(left,cost):
        nonlocal count,best,opt
        if not left:
            count+=1
            if cost<best:best=cost;opt=1
            elif cost==best:opt+=1
            return
        e=min(left,key=lambda e:len({1,2,3}-used[e[0]]-used[e[1]]));u,v=e
        for c in {1,2,3}-used[u]-used[v]:
            used[u].add(c);used[v].add(c);visit(left-{e},cost+int(e in M and c!=3));used[u].remove(c);used[v].remove(c)
    visit(set(es),0);return best,count,opt

if __name__=='__main__':
    rows=[solve(k) for k in (1,2,4,8,16,32,64,128,256,512)]
    for k in (1,2):
        row=rows[k-1]; assert brute(k)==(row['minimum_exceptions'],int(row['total_colorings']),int(row['optimal_colorings']))
    print([(r['vertices'],r['minimum_exceptions'],r['peak_states'],r['transition_checks']) for r in rows]); print('states',len(S),'transitions',sum(map(len,trans.values())))
    Path(__file__).with_name('CC04_rim_repair_results.json').write_text(json.dumps(rows,indent=2))

# General path-of-rims backend: no construction manifest, no known coloring.
def acquire_and_solve(G,M,cap=5):
    M={tuple(sorted(e)) for e in M}; H=G.copy();H.remove_edges_from(M)
    assert all(d==2 for _,d in H.degree()) and len(M)*2==len(G)
    rims=[];owner={}
    for comp in nx.connected_components(H):
        root=min(comp);r=[root];prev=None;v=root
        while True:
            u=min(u for u in H[v] if u!=prev)
            if u==root:break
            r.append(u);prev,v=v,u
        assert len(r)==len(comp)
        for v in r:owner[v]=len(rims)
        rims.append(r)
    Q=nx.Graph();Q.add_nodes_from(range(len(rims))); bundles={}
    port={}
    for e in sorted(M):
        u,v=e;i,j=owner[u],owner[v]
        if i==j:return None
        ij=tuple(sorted((i,j)));Q.add_edge(*ij);bundles.setdefault(ij,[]).append(e);port[u]=port[v]=e
    if len(Q)<2 or not nx.is_tree(Q) or max(dict(Q.degree()).values())>2:return None
    if max(map(len,bundles.values()))>cap:return None
    order=[min(v for v in Q if Q.degree(v)==1)]
    while len(order)<len(Q):order.append(next(v for v in Q[order[-1]] if len(order)==1 or v!=order[-2]))
    bs=[bundles[tuple(sorted((i,j)))] for i,j in zip(order,order[1:])]
    # Sum of matching colors crossing a prefix is zero (flow conservation).
    states=[[s for s in product((1,2,3),repeat=len(b)) if reduce(xor,s,0)==0] for b in bs]
    def local(i,x,y):
        known={}
        if i:known.update(zip(bs[i-1],x))
        if i<len(bs):known.update(zip(bs[i],y))
        return phases([known[port[v]] for v in rims[order[i]]])
    dp={(): (0,1,1)};traces=[];peak=1;checks=0
    for i in range(len(order)):
        nd={};tr={}
        for x,(cost,count,opt) in dp.items():
            for y in states[i] if i<len(bs) else [()]:
                checks+=1;p=local(i,x,y)
                if not p:continue
                z=cost+sum(c!=3 for c in y);m=len(p);old=nd.get(y)
                if old is None:nd[y]=(z,count*m,opt*m);tr[y]=(x,p[0])
                else:
                    oc,ct,ot=old
                    if z<oc:nd[y]=(z,ct+count*m,opt*m);tr[y]=(x,p[0])
                    elif z==oc:nd[y]=(oc,ct+count*m,ot+opt*m)
                    else:nd[y]=(oc,ct+count*m,ot)
        dp=nd;traces.append(tr);peak=max(peak,len(dp))
    if () not in dp:return {'status':'UNSAT','peak_states':peak,'checks':checks}
    best,count,opt=dp[()];col={};y=()
    for i in reversed(range(len(order))):
        x,p=traces[i][y];r=rims[order[i]]
        col.update((tuple(sorted(e)),c) for e,c in zip(zip(r,r[1:]+r[:1]),p))
        if i<len(bs):col.update(zip(bs[i],y))
        y=x
    assert len(col)==G.number_of_edges() and all({col[tuple(sorted((v,u)))] for u in G[v]}=={1,2,3} for v in G)
    assert best==sum(col[e]!=3 for e in M)
    return {'status':'SAT','minimum_exceptions':best,'total_colorings':str(count),'optimal_colorings':str(opt),'peak_states':peak,'checks':checks}
